import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-service',
  templateUrl: './popular-service.component.html',
  styleUrls: ['./popular-service.component.scss']
})
export class PopularServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hireform',
  templateUrl: './hireform.component.html',
  styleUrls: ['./hireform.component.scss']
})
export class HireformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

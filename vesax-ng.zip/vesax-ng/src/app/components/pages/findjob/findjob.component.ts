import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-findjob',
  templateUrl: './findjob.component.html',
  styleUrls: ['./findjob.component.scss']
})
export class FindjobComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propertyrent',
  templateUrl: './propertyrent.component.html',
  styleUrls: ['./propertyrent.component.scss']
})
export class PropertyrentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
